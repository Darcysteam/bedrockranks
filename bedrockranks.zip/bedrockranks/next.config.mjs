export default { poweredByHeader: false };
